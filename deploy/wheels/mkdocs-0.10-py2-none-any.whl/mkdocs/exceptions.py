class ConfigurationError(Exception):
    """Error in configuration"""
